package uk.ac.cam.ms2316.oopjava.tick1;

public class PatternFormatException extends Exception {
	PatternFormatException(String msg) {
		super(msg);
	}
}